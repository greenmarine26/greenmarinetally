// (주)그린마린 직원 명단 — 접속 화이트리스트 + 직책 정보
// 작성: 2026-05-12 / 명단 사진 기준
// 새 직원 추가/퇴사자 삭제 시 이 파일 직접 편집

export const STAFF_LIST = [
  // 임원진
  { name: '최관묵', role: '회장' },
  { name: '신성호', role: '대표이사' },
  { name: '표인수', role: '상무이사' },
  { name: '황창웅', role: '이사' },

  // 실장/부장/차장/과장
  { name: '최장욱', role: '실장' },
  { name: '이현규', role: '부장(수석검수)' },
  { name: '김명보', role: '부장(수석검수)' },
  { name: '권수안', role: '차장' },
  { name: '정영배', role: '차장' },
  { name: '오승택', role: '차장(수석검수)' },
  { name: '성창모', role: '과장(수석검수)' },
  { name: '이강익', role: '과장(수석검수)' },

  // 대리
  { name: '김유신', role: '대리' },
  { name: '김석', role: '대리' },
  { name: '전우수', role: '대리(수석검수)' },
  { name: '김성일', role: '대리(부수석)' },

  // 검수
  { name: '장문영', role: '검수' },
  { name: '김판석', role: '검수' },
  { name: '최관식', role: '검수' },
  { name: '길태윤', role: '검수' },
  { name: '최유택', role: '검수' },
  { name: '김홍규', role: '검수' },
  { name: '천희준', role: '검수' },
  { name: '한성호', role: '검수' },
  { name: '이병진', role: '검수' },
  { name: '오종하', role: '검수' },
  { name: '이인철', role: '검수' },
  { name: '이종부', role: '검수' },
  { name: '최원형', role: '검수' },
];

// 이름만 배열로 (화이트리스트 검사용)
export const STAFF_NAMES = STAFF_LIST.map(s => s.name);

// 이름 → 직책 매핑
export const STAFF_ROLES = Object.fromEntries(STAFF_LIST.map(s => [s.name, s.role]));

// 정규화 (공백/특수문자 제거 후 비교용)
export function isStaff(name) {
  if (!name) return false;
  const norm = String(name).trim().replace(/[,\s\.\-_\/\\]/g, '');
  return STAFF_NAMES.some(n => n === norm || n.replace(/\s/g, '') === norm);
}

export function getStaffRole(name) {
  if (!name) return '';
  const norm = String(name).trim();
  return STAFF_ROLES[norm] || '';
}

// 수석검수 여부 (작업 권한)
export function isChief(name) {
  const role = getStaffRole(name);
  return /수석검수/.test(role);
}
