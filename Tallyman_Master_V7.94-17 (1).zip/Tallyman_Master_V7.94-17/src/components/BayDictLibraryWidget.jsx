// M6.43: 베이사전 라이브러리 위젯
//   - 등록 N척 / 누락 M척 / 등록률 % 표시
//   - 누락 선박 리스트 (단골 우선)
//   - PDF 단일 + 일괄 등록 버튼 통합 (한 위젯 안에서 다 처리)
import React, { useEffect, useMemo, useState, useRef } from 'react';
import { Database, ChevronDown, ChevronUp, AlertTriangle, CheckCircle2, Upload, FolderOpen } from 'lucide-react';
import { fbSubscribeShipBayDict, fbSubscribeShipLibrary } from '../firebase.js';

export default function BayDictLibraryWidget({ onSingleUpload, onBulkUpload, onAscUpload }) {
  const [bayDict, setBayDict] = useState({});
  const [ships, setShips] = useState({});
  const [expanded, setExpanded] = useState(false);
  const [filter, setFilter] = useState('missing');  // missing | all | registered
  const singleRef = useRef(null);

  useEffect(() => {
    const unsubDict = fbSubscribeShipBayDict(setBayDict);
    const unsubShips = fbSubscribeShipLibrary(setShips);
    return () => {
      try { unsubDict && unsubDict(); } catch (_) {}
      try { unsubShips && unsubShips(); } catch (_) {}
    };
  }, []);

  const stats = useMemo(() => {
    const dictEntries = Object.values(bayDict || {});
    const totalRegistered = dictEntries.length;

    const dictImos = new Set();
    const dictCodes = new Set();
    const dictCallsigns = new Set();
    dictEntries.forEach(e => {
      if (e.imo) dictImos.add(String(e.imo));
      if (e.code) dictCodes.add(String(e.code).toUpperCase());
      if (e.callsign) dictCallsigns.add(String(e.callsign).toUpperCase());
    });

    const shipEntries = Object.entries(ships || {});
    const totalShipped = shipEntries.length;

    const missing = [];
    const registered = [];
    shipEntries.forEach(([imo, sh]) => {
      const code4 = (sh.name || '').replace(/\s+/g, '').slice(0, 4).toUpperCase();
      const inDict = dictImos.has(imo)
        || (sh.callsign && dictCallsigns.has(String(sh.callsign).toUpperCase()))
        || (sh.code && dictCodes.has(String(sh.code).toUpperCase()))
        || (code4 && dictCodes.has(code4));
      const voyCount = Object.keys(sh.voyages || {}).length;
      const item = {
        imo,
        name: sh.name || '?',
        callsign: sh.callsign || '',
        code: sh.code || code4 || '',
        voyCount,
        lastSeen: sh.lastSeenAt || 0,
      };
      if (inDict) registered.push(item);
      else missing.push(item);
    });
    // 입항 빈도순
    missing.sort((a, b) => b.voyCount - a.voyCount);
    registered.sort((a, b) => b.voyCount - a.voyCount);

    let verified = 0, needsReview = 0, others = 0, withPdf = 0;
    dictEntries.forEach(e => {
      if (e.bayDef?.verified) verified++;
      else if (e.bayDef?.grade === 'needs-review') needsReview++;
      else others++;
      if (e.pdfUrl) withPdf++;
    });

    return {
      totalRegistered, totalShipped, missing, registered,
      verified, needsReview, others, withPdf,
      regRate: totalShipped > 0 ? Math.round((registered.length / totalShipped) * 100) : 0,
    };
  }, [bayDict, ships]);

  const filteredList = filter === 'missing' ? stats.missing
                     : filter === 'registered' ? stats.registered
                     : [...stats.missing, ...stats.registered];

  const handleSingleSelect = (e) => {
    const f = e.target.files?.[0];
    if (f && onSingleUpload) onSingleUpload(f);
    e.target.value = '';
  };

  return (
    <div className="bg-cyan-950/30 border border-cyan-700/50 rounded-lg overflow-hidden">
      {/* 헤더 — 전체 탭으로 펼침 */}
      <button
        onClick={() => setExpanded(v => !v)}
        className="w-full flex items-center gap-2 p-2.5 text-left hover:bg-cyan-900/20"
      >
        <Database className="w-4 h-4 text-cyan-400 shrink-0"/>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-black text-cyan-200 flex items-center gap-2 flex-wrap">
            📚 베이사전 라이브러리
            <span className="bg-emerald-700/60 text-emerald-100 px-1.5 py-0.5 rounded text-[9px]">
              {stats.totalRegistered}척 등록
            </span>
            {stats.missing.length > 0 && (
              <span className="bg-amber-700/60 text-amber-100 px-1.5 py-0.5 rounded text-[9px]">
                ⚠️ {stats.missing.length}척 누락
              </span>
            )}
            {stats.totalShipped > 0 && (
              <span className="text-cyan-400/80 text-[10px]">
                등록률 {stats.regRate}%
              </span>
            )}
          </div>
          <div className="text-[10px] text-cyan-400/70 mt-0.5">
            평택 입항 이력 {stats.totalShipped}척 · 검증 {stats.verified} · PDF 보관 {stats.withPdf}
          </div>
        </div>
        <span className="text-cyan-300 px-1 shrink-0">
          {expanded ? <ChevronUp className="w-5 h-5"/> : <ChevronDown className="w-5 h-5"/>}
        </span>
      </button>

      {expanded && (
        <div className="border-t border-cyan-700/40 p-2.5 space-y-2">
          {/* PDF/ASC 등록 버튼 — 위젯 안에서 직접 */}
          <div className="space-y-1.5">
            {/* M6.47: ASC 일괄 — Gemini 0, 즉시 */}
            <button
              onClick={() => onAscUpload && onAscUpload()}
              className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-xs font-bold"
            >
              ⚡ ASC 일괄 등록 (Gemini 0, 즉시)
            </button>
            {/* M6.70: PDF 옵션 — 앱 내장 자체 파서 (Gemini 의존 0) */}
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => onBulkUpload && onBulkUpload()}
                className="flex-1 min-w-[120px] inline-flex items-center justify-center gap-1.5 px-2.5 py-2 bg-purple-700 hover:bg-purple-600 text-white rounded text-xs font-bold"
              >
                <FolderOpen className="w-3.5 h-3.5"/>
                📚 PDF 일괄 (M6.70 자체)
              </button>
              <label className="flex-1 min-w-[120px] cursor-pointer inline-flex items-center justify-center gap-1.5 px-2.5 py-2 bg-purple-900/50 hover:bg-purple-800/50 border border-purple-700/50 rounded text-xs font-bold text-purple-200">
                <Upload className="w-3.5 h-3.5"/>
                📄 PDF 1개 (자체)
                <input
                  ref={singleRef}
                  type="file"
                  accept="application/pdf,.pdf"
                  className="hidden"
                  onChange={handleSingleSelect}
                />
              </label>
            </div>
          </div>

          {/* 필터 탭 */}
          <div className="flex gap-1 text-[10px]">
            <button
              onClick={() => setFilter('missing')}
              className={`px-2 py-1 rounded ${filter === 'missing' ? 'bg-amber-700 text-amber-50' : 'bg-slate-800 text-slate-400'}`}
            >
              ⚠️ 누락 ({stats.missing.length})
            </button>
            <button
              onClick={() => setFilter('registered')}
              className={`px-2 py-1 rounded ${filter === 'registered' ? 'bg-emerald-700 text-emerald-50' : 'bg-slate-800 text-slate-400'}`}
            >
              ✅ 등록 ({stats.registered.length})
            </button>
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-1 rounded ${filter === 'all' ? 'bg-cyan-700 text-cyan-50' : 'bg-slate-800 text-slate-400'}`}
            >
              전체 ({stats.totalShipped})
            </button>
          </div>

          {/* 선박 리스트 */}
          <div className="max-h-60 overflow-y-auto space-y-1">
            {filteredList.length === 0 ? (
              <div className="text-center py-4 text-[10px] text-slate-500">
                {filter === 'missing' ? '🎉 모든 입항 선박 등록 완료' : '선박 없음'}
              </div>
            ) : (
              filteredList.map(s => {
                const isMissing = !stats.registered.find(r => r.imo === s.imo);
                return (
                  <div
                    key={s.imo}
                    className={`flex items-center gap-2 p-1.5 rounded text-[10px] ${
                      isMissing ? 'bg-amber-950/30 border border-amber-800/40' : 'bg-emerald-950/30 border border-emerald-800/40'
                    }`}
                  >
                    {isMissing ? (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0"/>
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0"/>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="text-slate-100 truncate">{s.name}</div>
                      <div className="text-slate-400 truncate">
                        {s.code && <span className="text-purple-300">{s.code}</span>}
                        {s.callsign && <span className="ml-1">· {s.callsign}</span>}
                        <span className="ml-1">· 입항 {s.voyCount}회</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="text-[10px] text-cyan-400/70 pt-1 border-t border-cyan-700/30">
            💡 누락 선박은 일괄 등록으로 빠르게 추가하거나, 입항 시 자동으로 추가됩니다
          </div>
        </div>
      )}
    </div>
  );
}
